class CollectionName{
  String admin ="admin";
  String usageControls ="usageControls";
  String userAppSettings ="userAppSettings";
  String chatWith ="chatWith";
  String agoraToken ="agoraToken";
  String users ="users";
  String chats ="chats";
  String chat ="chat";
  String calls ="calls";
  String calling ="calling";
  String status ="status";
  String groups ="groups";
  String collectionCallHistory ="collectionCallHistory";
  String broadcastMessage ="broadcastMessage";
  String messages ="messages";
  String broadcast ="broadcast";
  String groupMessage ="groupMessage";

  String config ="config";
  String adminStatus ="adminStatus";
  String wallpaper ="wallpaper";
  String userContact ="userContact";
  String report ="report";
  String allContact ="allContact";
  String registerUser ="registerUser";
  String unRegisterUser ="unRegisterUser";

}