export 'package:leadvala/screens/auth_screens/auth_screen_list.dart';

export 'package:leadvala/screens/bottom_screens/bottom_screen_list.dart';
export 'package:leadvala/screens/app_pages_screens/app_pages_screen_list.dart';
