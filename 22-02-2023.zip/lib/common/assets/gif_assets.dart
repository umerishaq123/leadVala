class GifAssets {
  final successGif = "assets/gif/successGif.gif";
  final loader = "assets/gif/loader.gif";
  final wallet = "assets/gif/wallet.gif";
  final tick = "assets/gif/tick.gif";
  final cross = "assets/gif/cross.gif";
  final hold = "assets/gif/hold.gif";
  final completeBooking = "assets/gif/completeBooking.gif";
  final restart = "assets/gif/restart.gif";
  final bad = "assets/gif/bad.gif";
  final okay = "assets/gif/okay.gif";
  final good = "assets/gif/good.gif";
  final amazing = "assets/gif/amazing.gif";
  final excellent = "assets/gif/excellent.gif";
}
