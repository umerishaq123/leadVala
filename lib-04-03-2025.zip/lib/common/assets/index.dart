import 'package:leadvala/common/assets/gif_assets.dart';
import 'package:leadvala/common/assets/svg_assets.dart';

import 'image_assets.dart';

ImageAssets eImageAssets = ImageAssets();
SvgAssets eSvgAssets = SvgAssets();
GifAssets eGifAssets = GifAssets();


