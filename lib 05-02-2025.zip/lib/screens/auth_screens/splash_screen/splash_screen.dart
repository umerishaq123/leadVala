
import 'dart:async';



import '../../../config.dart';
import '../../../widgets/alert_message_common.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with TickerProviderStateMixin {

  @override
  void initState() {
    final SplashProvider splash =
    Provider.of<SplashProvider>(context, listen: false);
splash.onReady(this, context);
    // TODO: implement initState
    super.initState();
    checkLoginStatus();
  }


  late SharedPreferences pref;
  bool isLoggedIn = false;




  void checkLoginStatus() async {
    pref = await SharedPreferences.getInstance();
    bool isLoggedIn = pref.getBool("isLoggedIn") ?? false;
    print("Is login====${isLoggedIn}");

    if (true) {
      final commonApi = Provider.of<CommonApiProvider>(context, listen: false);
      await commonApi.selfApi(context);

      // final dashboardProvider = Provider.of<DashboardProvider>(context, listen: true);
      // final locationCtrl = Provider.of<LocationProvider>(context, listen: false);
      // await locationCtrl.getZoneId();
      // dashboardProvider.getBanner();
      // dashboardProvider.getOffer();
      // dashboardProvider.getCoupons();
      //
      // dashboardProvider.getCategory();
      // dashboardProvider.getServicePackage();
      // dashboardProvider.getProvider();
      //
      // dashboardProvider.getFeaturedPackage(1);
      // dashboardProvider.getHighestRate();
      // dashboardProvider.getBlog();


      Future.delayed(const Duration(milliseconds: 500), () {
        route.pushReplacementNamed(context, routeName.dashboard);
      });
    } else {
      Future.delayed(const Duration(milliseconds: 500), () {
        Navigator.pushReplacementNamed(context, routeName.login);
      });
    }

  }

  @override
  Widget build(BuildContext context) {

    return Consumer<SplashProvider>(builder: (context, splash, child) {
      return StatefulWrapper(
          onInit: ()=> Timer(const Duration(milliseconds: 200), ()=>  splash.onChangeSize()),

          child: Scaffold(
              body: Center(
                  child: Column(children: [
            Stack(alignment: Alignment.center, children: [
              if(splash.animation2 != null)
              CircularRevealAnimation(
                  animation: splash.animation2!,
                  centerAlignment: Alignment.center,
                  minRadius: 12,
                  maxRadius: 600,
                  child: Container(
                      color: appColor(context)

                          .primary
                          .withOpacity(0.7),
                      width: MediaQuery.of(context).size.width,
                      height: MediaQuery.of(context).size.height,
                      child: Opacity(
                          opacity: 0.15,
                          child: Image.asset(eImageAssets.splashBg,
                              fit: BoxFit.cover)))),
              Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                if(splash.controller != null)
                const RotationAnimationLayout(),
                const VSpace(Sizes.s15),
                if(splash.controller != null)
                if (splash.controller!.isCompleted)
                  SlideTransition(
                      position: Tween<Offset>(
                              begin: const Offset(0, 2),
                              end: const Offset(0, -0.1))
                          .animate(splash.popUpAnimationController!),
                      child: Text(language(context, appFonts.fixit),
                          style: appCss.outfitSemiBold45.textColor(
                              appColor(context).whiteColor)))
              ])
            ])
          ]))));
    });
  }
}
